#!/bin/sh
set -eu
base=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ "$#" -ne 1 ]; then echo 'usage: download-update.sh URL' >&2; exit 64; fi
export LD_LIBRARY_PATH="$base/lib"
exec "$base/bin/curl" --config "$base/etc/download.conf" --url "$1"
